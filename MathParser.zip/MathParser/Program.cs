﻿//Olu Ogundimu
using System;
using System.Collections;
using System.Text;


namespace MathParser
{
    class Program
    {
        private const string operators = "abcedf"; 

        static void Main(string[] args)
        {
            do
            {
                Console.WriteLine("Enter math expression (press CTRL+C to exit):");
                Console.WriteLine("The answer is {0}", MathParser(Console.ReadLine()));
	        } while (true);

            //string a = "3c4d2aee2a4c41fc4f";
            //string b = "3a2c4";
            //string c = "500a10b66c32";
            //string d = "32a2d2";
            //string e = "3ae4c66fb32";
            //string f = "2d2";
        }

        ///olu ogundimu
        /// <summary>
        /// Does the calculation
        /// </summary>
        /// <param name="operatore">Operator</param>
        /// <param name="operandLeft">Left Operand</param>
        /// <param name="operandRight">Right Operand</param>
        /// <returns></returns>
        private static double calculate(string operatore, string operandLeft, string operandRight)
        {
            double result = 0.00;
            switch (operatore)
            {
                case "a":
                    result = Convert.ToDouble(operandLeft) + Convert.ToDouble(operandRight);
                    break;
                case "b":
                    result = Convert.ToDouble(operandLeft) - Convert.ToDouble(operandRight);
                    break;
                case "c":
                    result = Convert.ToDouble(operandLeft) * Convert.ToDouble(operandRight);
                    break;
                case "d":
                    result = Convert.ToDouble(operandLeft) / Convert.ToDouble(operandRight);
                    break;
                default:
                    break;
            }
            return result;
        }

        /// <summary>
        /// The workhorse. move infix to postfix to compute
        /// </summary>
        /// <param name="input">equation input</param>
        /// <returns></returns>
        private static string MathParser(string input)
        {
            char[] calInput = input.ToCharArray();
            Int64 n;

            if (string.IsNullOrEmpty(input) || (!Int64.TryParse(calInput[0].ToString(), out n) && calInput[0] != 'b' && calInput[0] != 'e'))
            {
                Console.WriteLine("Input is not well formed Math expression");
                return string.Empty;
            }

            Stack rr = new Stack();
            StringBuilder chars = new StringBuilder();

            //loop through each Xter of the input
            for (int j = 0; j < calInput.Length; j++)
            {
                //check if this input loop is a number
                // and stores it until the next operator
                if (Int64.TryParse(calInput[j].ToString(), out n))
                {
                    chars.Append(calInput[j]);
                    //on the last loop if the item is a number finallise our calculation
                    if (j == calInput.Length - 1)
                    {
                        rr.Push(calculate(rr.Pop().ToString(), rr.Pop().ToString(), chars.ToString()));
                    }
                }
                else
                {
                    //handle neagtive numbers
                    if (((rr.Count > 0 && chars.Length == 0 && !Int64.TryParse(rr.Peek().ToString(), out n)) || j == 0) && calInput[j] == 'b')
                    {
                        chars.Append("-");
                        continue;
                    }

                    //once we encounter an operator in our loop.
                    //based on the if criteria below
                    if (rr.Count > 1 && rr.Peek().ToString() != "e" && calInput[j] != 'e' && chars.Length > 0)
                    {
                        rr.Push(calculate(rr.Pop().ToString(), rr.Pop().ToString(), chars.ToString()));

                        //if this loop is f ')' then calculate 
                        if (calInput[j] == 'f')
                        {
                            //store top of the stack locally
                            string temp = rr.Pop().ToString();
                            //remove the e '('
                            rr.Pop();
                            //push temp variable value back on the stack, this would have conculded the
                            //the calculations for the items in a bracket.
                            rr.Push(temp);
                            //perform calcuation on all items on the stack if no more brackets.
                            //provided there are items to calculate on the stack
                            //this will leave one item on the stack.
                            if (!rr.Contains('e') && rr.Count > 2)
                            {
                                string topValue = rr.Pop().ToString();
                                rr.Push(calculate(rr.Pop().ToString(), rr.Pop().ToString(), topValue));
                            }
                        }
                        else
                        {
                            //just store the operator if it is not e '(' or f ')'
                            rr.Push(calInput[j]);
                        }
                        chars.Clear();
                    }
                    else
                    {
                        if (chars.Length > 0)
                        {
                            rr.Push(chars.ToString());
                            chars.Clear();
                        }
                        rr.Push(calInput[j]);
                    }
                }
            }

            double result = Convert.ToDouble(rr.Pop());
            return result.ToString("0.00");
        }
    }
}
//olu ogundimu
